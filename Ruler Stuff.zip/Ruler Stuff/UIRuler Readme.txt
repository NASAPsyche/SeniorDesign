For ruler to show, attach the uiruler prefab to the main canvas of the scene.

Just in case, check to see if uiruler has the image attached 
as well as whether or not the image is in sprite mode or not.

To have the script work correctly, pick the scene's asteroid for vesta.
 
If any of the other variables say 'none':

	CurrentRulerLength: Pick DynamicDistanceEnd

	uiRuler: Pick the UIRuler that the script is attached to. 
		-Using the original ruler image won't allow the code to scale 
		with resolution

	Camera: It gets assigned to the main camera automatically, 
		but you can change to a different if you'd like.
